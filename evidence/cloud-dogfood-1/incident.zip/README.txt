This is a signed evidence bundle from @edut/mcp-recorder: 12 redacted MCP event(s), seq 1..12 of the full event chain, sealed in a SHA-256 hash chain.
How to verify (needs only Node.js, no packages):  node verify.cjs
PASS proves the events are complete, in order, and byte-for-byte unaltered since export, and that the chain head was signed by the holder of the bundled ed25519 public key.
Generated 2026-09-15T12:18:30.240Z by @edut/mcp-recorder v0.1.0; details in manifest.json.
