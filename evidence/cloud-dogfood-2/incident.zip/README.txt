This is a signed evidence bundle from @edut/mcp-recorder: 14 redacted MCP event(s), seq 1..14 of the full event chain, sealed in a SHA-256 hash chain.
How to verify (needs only Node.js, no packages):  node verify.cjs
PASS proves the events are complete, in order, and byte-for-byte unaltered since export, and that the chain head was signed by the holder of the bundled ed25519 public key.
Generated 2026-09-15T14:29:13.172Z by @edut/mcp-recorder v0.1.0; details in manifest.json.
